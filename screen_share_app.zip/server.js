// server.js (WebSocket Server)
const WebSocket = require('ws');
const server = new WebSocket.Server({ port: 8080 });

let viewers = [];

server.on('connection', socket => {
  socket.on('message', data => {
    viewers.forEach(v => {
      if (v !== socket && v.readyState === WebSocket.OPEN) {
        v.send(data);
      }
    });
  });

  viewers.push(socket);

  socket.on('close', () => {
    viewers = viewers.filter(s => s !== socket);
  });
});

console.log("WebSocket server started on ws://localhost:8080");
